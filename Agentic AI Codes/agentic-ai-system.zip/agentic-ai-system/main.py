#!/usr/bin/env python3
"""
Main entry point for the Advanced Self-Evaluating Agentic AI System

This script provides a simple way to run the system from the command line
or integrate it into other applications.
"""

import asyncio
import os
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / "src"))

from agentic_ai.cli import cli

if __name__ == "__main__":
    cli()
