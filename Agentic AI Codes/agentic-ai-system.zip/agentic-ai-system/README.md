# Advanced Self-Evaluating Agentic AI System

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

A comprehensive agentic AI system with self-evaluation capabilities, advanced knowledge management, and robust evaluation metrics. Built with LlamaIndex and OpenAI, this system goes beyond simple chatbots to provide reliable, trustworthy AI interactions with automatic quality assessment.

Based on the tutorial from [MarkTechPost](https://www.marktechpost.com/2026/01/17/how-to-build-a-self-evaluating-agentic-ai-system-with-llamaindex-and-openai-using-retrieval-tool-use-and-automated-quality-checks/).

## ✨ Key Features

### 🤖 Self-Evaluation & Quality Assurance
- **Automatic Quality Assessment**: Built-in faithfulness and relevancy evaluation
- **Multi-Metric Analysis**: Comprehensive scoring with detailed feedback
- **Self-Revision Capability**: Automatic response improvement based on evaluation
- **Threshold Management**: Configurable quality thresholds for different use cases

### 📚 Advanced Knowledge Management
- **Dynamic Knowledge Base**: Real-time document indexing and retrieval
- **Multi-Format Support**: Text documents, PDFs, and directory loading
- **Metadata Tracking**: Comprehensive document metadata and statistics
- **Semantic Search**: Vector-based similarity search with relevance scoring

### 🔧 Production-Ready Features
- **Configuration Management**: YAML-based configuration with environment variable support
- **Comprehensive Logging**: Structured logging with performance monitoring
- **Session Management**: Request tracking and performance analytics
- **Data Export**: JSON export for analysis and monitoring
- **Error Handling**: Robust error recovery and graceful degradation

### 🎯 Tool Integration
- **Evidence Retrieval**: Automatic context gathering from knowledge base
- **Answer Scoring**: Real-time evaluation with detailed metrics
- **Knowledge Addition**: Dynamic knowledge base updates
- **Statistics Monitoring**: Real-time performance and usage statistics

## 🚀 Quick Start

### Installation

```bash
# Clone the repository
git clone <repository-url>
cd advanced-agentic-ai

# Install dependencies
pip install -r requirements.txt

# Set your OpenAI API key
export OPENAI_API_KEY="your-api-key-here"
```

### Basic Usage

```python
from src.agentic_ai import SystemConfig, AdvancedAgenticAI

# Initialize the system
config = SystemConfig()
config.openai.api_key = "your-api-key"

ai_system = AdvancedAgenticAI(config)
ai_system.start_session("my_session")

# Process a query
response = await ai_system.process_query(
    "What are the key components of a reliable RAG system?"
)

print(f"Response: {response.response}")
print(f"Quality Score: {response.evaluation.overall_score:.2f}")
```

### Command Line Interface

```bash
# Interactive chat mode
python main.py chat --interactive

# Single query processing
python main.py chat "Explain self-evaluating AI systems"

# Load documents from directory
python main.py load-documents ./documents --tags "research,ai"

# Search knowledge base
python main.py search "RAG evaluation metrics" --top-k 5

# Initialize configuration file
python main.py init-config --output config.yaml
```

## 📖 Examples

### Jupyter Notebook Tutorial
Comprehensive tutorial covering all features:
```bash
jupyter notebook examples/tutorial.ipynb
```

### Python Examples
Complete examples with error handling and advanced usage:
```bash
python examples/complete_example.py
```

### CLI Examples
```bash
# Start interactive session
python main.py chat -i

# Process query with configuration
python main.py --config config.yaml chat "Your query here"

# Export session data
python main.py chat -i --export session_data.json
```

## ⚙️ Configuration

The system uses YAML-based configuration with the following structure:

```yaml
openai:
  api_key: "your-api-key"
  model: "gpt-4o-mini"
  embedding_model: "text-embedding-3-small"
  temperature: 0.2

evaluation:
  faithfulness_threshold: 0.7
  relevancy_threshold: 0.7
  quality_threshold: 0.7
  enable_faithfulness: true
  enable_relevancy: true

agent:
  max_iterations: 5
  enable_self_revision: true
  max_revisions: 2
  verbose: true

knowledge_base:
  chunk_size: 512
  chunk_overlap: 50
  similarity_top_k: 4
```

### Environment Variables
- `OPENAI_API_KEY`: Your OpenAI API key
- `OPENAI_MODEL`: Model to use (default: gpt-4o-mini)
- `OPENAI_EMBEDDING_MODEL`: Embedding model (default: text-embedding-3-small)

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Advanced Agentic AI System               │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   Agent     │  │ Knowledge   │  │    Evaluation       │  │
│  │  Workflow   │◄─┤    Base     │  │     System          │  │
│  │             │  │             │  │                     │  │
│  │ • ReAct     │  │ • Vector    │  │ • Faithfulness      │  │
│  │ • Tools     │  │   Index     │  │ • Relevancy         │  │
│  │ • Self-Rev  │  │ • Metadata  │  │ • Quality Metrics   │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
├─────────────────────────────────────────────────────────────┤
│              Configuration & Session Management             │
└─────────────────────────────────────────────────────────────┘
```

### Core Components

1. **Agent System** (`agent.py`)
   - ReAct-based reasoning workflow
   - Tool integration and validation
   - Self-revision capabilities
   - Session management

2. **Knowledge Base** (`knowledge_base.py`)
   - Document indexing and retrieval
   - Metadata management
   - Semantic search capabilities
   - Statistics tracking

3. **Evaluation System** (`evaluation.py`)
   - Multi-metric evaluation
   - Automated quality assessment
   - Detailed feedback generation
   - Performance monitoring

4. **Configuration** (`config.py`)
   - YAML-based configuration
   - Environment variable support
   - Validation and defaults

## 📊 Evaluation Metrics

The system provides comprehensive evaluation with the following metrics:

### Core Metrics
- **Faithfulness Score**: How well the response is grounded in retrieved context
- **Relevancy Score**: How relevant the response is to the original query  
- **Answer Quality**: Overall quality and coherence of the response
- **Context Quality**: Relevance of retrieved context to the query

### Performance Metrics
- **Processing Time**: Total time for query processing
- **Evaluation Time**: Time spent on quality assessment
- **Success Rate**: Percentage of responses meeting quality thresholds
- **Average Score**: Mean quality score across session

### Quality Thresholds
Configurable thresholds determine response acceptability:
- Default: 0.7 for all metrics
- Strict mode: 0.9 for production systems
- Lenient mode: 0.5 for experimental use

## 🛠️ Advanced Usage

### Custom Knowledge Base
```python
# Add documents programmatically
ai_system.knowledge_base.add_text_documents(
    texts=["Your custom knowledge here"],
    titles=["Custom Document"],
    tags=["custom", "knowledge"]
)

# Load from directory
ai_system.knowledge_base.load_from_directory(
    "path/to/documents",
    tags=["domain-specific"]
)
```

### Custom Evaluation
```python
from agentic_ai.evaluation import AdvancedEvaluator

evaluator = AdvancedEvaluator(llm, config)
result = await evaluator.evaluate_response(
    query="Your query",
    response="AI response", 
    contexts=["Retrieved context"]
)
```

### Session Analysis
```python
# Get session statistics
stats = ai_system.get_session_stats()
history = ai_system.get_response_history()

# Export for analysis
ai_system.export_session("analysis_data.json")
```

## 🧪 Testing

Run the test suite:
```bash
# Basic functionality test
python examples/complete_example.py

# Interactive testing
python main.py chat --interactive

# Performance testing
python -m pytest tests/ -v
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Based on the tutorial from [MarkTechPost](https://www.marktechpost.com/2026/01/17/how-to-build-a-self-evaluating-agentic-ai-system-with-llamaindex-and-openai-using-retrieval-tool-use-and-automated-quality-checks/)
- Built with [LlamaIndex](https://github.com/jerryjliu/llama_index)
- Powered by [OpenAI](https://openai.com/)
- CLI interface using [Click](https://click.palletsprojects.com/) and [Rich](https://rich.readthedocs.io/)

## 📞 Support

For questions, issues, or contributions:
- Create an issue on GitHub
- Check the examples and documentation
- Review the tutorial notebook for detailed usage

---

**Built with ❤️ for the AI community**
