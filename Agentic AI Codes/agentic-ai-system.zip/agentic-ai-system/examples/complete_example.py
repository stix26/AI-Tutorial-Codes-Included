"""
Complete Example: Advanced Self-Evaluating Agentic AI System

This example demonstrates all the key features of the system:
- Configuration management
- Knowledge base operations
- Agent querying with self-evaluation
- Session management and statistics
- Performance monitoring
"""

import asyncio
import os
from pathlib import Path
import json
from datetime import datetime

# Set up environment
os.environ["OPENAI_API_KEY"] = "your-api-key-here"  # Replace with your key

from src.agentic_ai import (
    SystemConfig,
    AdvancedAgenticAI,
    load_config,
    save_config
)


async def main():
    """Main example function demonstrating the system capabilities."""
    
    print("🚀 Advanced Self-Evaluating Agentic AI System Example")
    print("=" * 60)
    
    # Step 1: Configuration Management
    print("\n1. Setting up Configuration...")
    
    config = SystemConfig()
    config.openai.api_key = os.getenv("OPENAI_API_KEY")
    config.openai.model = "gpt-4o-mini"
    config.openai.temperature = 0.2
    
    # Customize evaluation thresholds
    config.evaluation.faithfulness_threshold = 0.8
    config.evaluation.relevancy_threshold = 0.8
    config.evaluation.quality_threshold = 0.75
    
    # Agent configuration
    config.agent.verbose = True
    config.agent.max_iterations = 5
    config.agent.enable_self_revision = True
    
    print(f"✅ Configuration loaded with model: {config.openai.model}")
    
    # Step 2: Initialize the AI System
    print("\n2. Initializing AI System...")
    
    ai_system = AdvancedAgenticAI(config)
    session_id = ai_system.start_session("example_session")
    
    print(f"✅ AI system initialized with session: {session_id}")
    
    # Step 3: Knowledge Base Operations
    print("\n3. Managing Knowledge Base...")
    
    # Add custom knowledge
    custom_knowledge = [
        {
            "text": "Advanced agentic AI systems implement multi-modal reasoning capabilities. "
                   "They can process text, images, and structured data simultaneously to provide "
                   "comprehensive analysis and insights. These systems use attention mechanisms "
                   "to focus on relevant information across different modalities.",
            "title": "Multi-modal Agentic AI",
            "tags": ["multimodal", "attention", "reasoning"]
        },
        {
            "text": "Self-evaluation in AI systems involves metacognitive processes where the system "
                   "monitors its own performance and adjusts behavior accordingly. Key components "
                   "include confidence estimation, error detection, and adaptive response generation. "
                   "These capabilities enable more reliable and trustworthy AI interactions.",
            "title": "AI Self-Evaluation Mechanisms",
            "tags": ["self-evaluation", "metacognition", "reliability"]
        },
        {
            "text": "Retrieval-Augmented Generation (RAG) systems combine parametric knowledge from "
                   "language models with non-parametric knowledge from external sources. "
                   "Advanced RAG implementations use hybrid retrieval, re-ranking, and "
                   "iterative refinement to improve answer quality and factual accuracy.",
            "title": "Advanced RAG Techniques",
            "tags": ["rag", "retrieval", "accuracy"]
        }
    ]
    
    for knowledge in custom_knowledge:
        ai_system.add_knowledge_from_text(
            knowledge["text"],
            knowledge["title"],
            knowledge["tags"]
        )
    
    # Show knowledge base stats
    kb_stats = ai_system.knowledge_base.get_stats()
    print(f"✅ Knowledge base updated: {kb_stats.total_documents} documents, {kb_stats.total_nodes} nodes")
    
    # Step 4: Process Complex Queries
    print("\n4. Processing Complex Queries...")
    
    test_queries = [
        "How do self-evaluating AI systems monitor their own performance and ensure reliability?",
        "What are the key components of advanced RAG systems and how do they improve accuracy?",
        "Explain the role of attention mechanisms in multi-modal agentic AI systems.",
        "Design a comprehensive evaluation framework for agentic AI systems that includes both "
        "automated metrics and human feedback loops."
    ]
    
    responses = []
    
    for i, query in enumerate(test_queries, 1):
        print(f"\n--- Query {i} ---")
        print(f"Q: {query}")
        
        try:
            response = await ai_system.process_query(query)
            responses.append(response)
            
            print(f"A: {response.response[:200]}...")
            
            if response.evaluation:
                eval_result = response.evaluation
                print(f"📊 Evaluation Scores:")
                print(f"  • Overall: {eval_result.overall_score:.2f}")
                print(f"  • Faithfulness: {eval_result.faithfulness_score:.2f}")
                print(f"  • Relevancy: {eval_result.relevancy_score:.2f}")
                print(f"  • Quality: {eval_result.answer_relevancy_score:.2f}")
                print(f"  • Status: {'✅ PASSED' if eval_result.passed_thresholds else '❌ NEEDS IMPROVEMENT'}")
                
                if not eval_result.passed_thresholds:
                    print(f"💡 Recommendations:")
                    for rec in eval_result.detailed_feedback.get('recommendations', []):
                        print(f"    - {rec}")
            
            print(f"⏱️ Processing time: {response.total_time:.2f}s")
            
        except Exception as e:
            print(f"❌ Error processing query: {e}")
    
    # Step 5: Session Statistics and Analysis
    print("\n5. Session Statistics and Analysis...")
    
    session_stats = ai_system.get_session_stats()
    if session_stats:
        print(f"📈 Session Performance:")
        print(f"  • Queries processed: {session_stats['queries_processed']}")
        print(f"  • Successful responses: {session_stats['successful_responses']}")
        print(f"  • Success rate: {session_stats['successful_responses']/session_stats['queries_processed']*100:.1f}%")
        print(f"  • Average score: {session_stats['average_score']:.2f}")
        print(f"  • Total evaluation time: {session_stats['total_evaluation_time']:.2f}s")
    
    # Step 6: Knowledge Base Search
    print("\n6. Knowledge Base Search Capabilities...")
    
    search_queries = [
        "attention mechanisms",
        "self-evaluation reliability",
        "RAG accuracy improvements"
    ]
    
    for search_query in search_queries:
        results = ai_system.knowledge_base.search(search_query, top_k=3)
        print(f"\n🔍 Search: '{search_query}' ({len(results)} results)")
        
        for j, result in enumerate(results[:2], 1):  # Show top 2 results
            print(f"  {j}. Score: {result.get('score', 0.0):.2f}")
            print(f"     Content: {result['content'][:100]}...")
    
    # Step 7: Export Session Data
    print("\n7. Exporting Session Data...")
    
    export_file = f"session_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    ai_system.export_session(export_file)
    
    print(f"✅ Session data exported to: {export_file}")
    
    # Step 8: Configuration Export
    print("\n8. Saving Configuration...")
    
    config_file = "advanced_ai_config.yaml"
    save_config(config, Path(config_file))
    
    print(f"✅ Configuration saved to: {config_file}")
    
    # Summary
    print("\n" + "=" * 60)
    print("🎉 Example Complete!")
    print(f"   • Processed {len(test_queries)} complex queries")
    print(f"   • Added {len(custom_knowledge)} knowledge documents")
    print(f"   • Performed {len(search_queries)} knowledge base searches")
    print(f"   • Exported session data and configuration")
    print("=" * 60)


def demonstrate_error_handling():
    """Demonstrate robust error handling capabilities."""
    
    print("\n🛠️  Error Handling Demonstration")
    print("-" * 40)
    
    try:
        # Test with invalid API key
        config = SystemConfig()
        config.openai.api_key = "invalid-key"
        
        ai_system = AdvancedAgenticAI(config)
        
    except Exception as e:
        print(f"✅ Caught configuration error: {type(e).__name__}")
    
    # Test with valid config but network issues
    try:
        config = SystemConfig()
        config.openai.api_key = os.getenv("OPENAI_API_KEY", "test-key")
        
        ai_system = AdvancedAgenticAI(config)
        
        # This would handle network/API errors gracefully
        print("✅ System handles network errors gracefully")
        
    except Exception as e:
        print(f"✅ Handled system error: {type(e).__name__}")


async def interactive_demo():
    """Simple interactive demo."""
    
    print("\n🎮 Interactive Demo Mode")
    print("-" * 30)
    print("Enter queries or 'quit' to exit")
    
    config = SystemConfig()
    config.openai.api_key = os.getenv("OPENAI_API_KEY")
    
    if not config.openai.api_key:
        print("❌ Please set OPENAI_API_KEY environment variable")
        return
    
    try:
        ai_system = AdvancedAgenticAI(config)
        ai_system.start_session("interactive_demo")
        
        while True:
            query = input("\n🤖 Your query: ")
            
            if query.lower() in ['quit', 'exit', 'q']:
                print("👋 Goodbye!")
                break
            
            if not query.strip():
                continue
            
            try:
                response = await ai_system.process_query(query)
                print(f"\n💬 Response: {response.response}")
                
                if response.evaluation:
                    score = response.evaluation.overall_score
                    status = "✅" if response.evaluation.passed_thresholds else "⚠️"
                    print(f"📊 Quality Score: {score:.2f} {status}")
                
            except Exception as e:
                print(f"❌ Error: {e}")
    
    except Exception as e:
        print(f"❌ System initialization failed: {e}")


if __name__ == "__main__":
    print("Choose an example to run:")
    print("1. Complete Example (recommended)")
    print("2. Error Handling Demo")
    print("3. Interactive Demo")
    
    choice = input("\nEnter choice (1-3): ").strip()
    
    if choice == "1":
        asyncio.run(main())
    elif choice == "2":
        demonstrate_error_handling()
    elif choice == "3":
        asyncio.run(interactive_demo())
    else:
        print("Invalid choice. Running complete example...")
        asyncio.run(main())
