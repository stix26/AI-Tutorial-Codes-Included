"""Configuration management for the Agentic AI System."""
import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional, List
from pydantic import BaseModel, Field
from dataclasses import dataclass


class OpenAIConfig(BaseModel):
    """OpenAI configuration settings."""
    api_key: Optional[str] = Field(default=None, description="OpenAI API key")
    model: str = Field(default="gpt-4o-mini", description="LLM model to use")
    embedding_model: str = Field(default="text-embedding-3-small", description="Embedding model")
    temperature: float = Field(default=0.2, description="Model temperature")
    max_tokens: int = Field(default=4000, description="Maximum tokens for response")


class EvaluationConfig(BaseModel):
    """Evaluation configuration settings."""
    enable_faithfulness: bool = Field(default=True, description="Enable faithfulness evaluation")
    enable_relevancy: bool = Field(default=True, description="Enable relevancy evaluation")
    enable_answer_quality: bool = Field(default=True, description="Enable answer quality evaluation")
    faithfulness_threshold: float = Field(default=0.7, description="Minimum faithfulness score")
    relevancy_threshold: float = Field(default=0.7, description="Minimum relevancy score")
    quality_threshold: float = Field(default=0.7, description="Minimum quality score")


class AgentConfig(BaseModel):
    """Agent configuration settings."""
    max_iterations: int = Field(default=5, description="Maximum agent iterations")
    enable_self_revision: bool = Field(default=True, description="Enable self-revision")
    max_revisions: int = Field(default=2, description="Maximum number of revisions")
    verbose: bool = Field(default=True, description="Enable verbose logging")
    similarity_top_k: int = Field(default=4, description="Top-k documents for retrieval")


class KnowledgeBaseConfig(BaseModel):
    """Knowledge base configuration settings."""
    chunk_size: int = Field(default=512, description="Document chunk size")
    chunk_overlap: int = Field(default=50, description="Chunk overlap size")
    enable_metadata: bool = Field(default=True, description="Enable metadata extraction")
    auto_index: bool = Field(default=True, description="Auto-index new documents")


class SystemConfig(BaseModel):
    """Main system configuration."""
    openai: OpenAIConfig = Field(default_factory=OpenAIConfig)
    evaluation: EvaluationConfig = Field(default_factory=EvaluationConfig)
    agent: AgentConfig = Field(default_factory=AgentConfig)
    knowledge_base: KnowledgeBaseConfig = Field(default_factory=KnowledgeBaseConfig)
    log_level: str = Field(default="INFO", description="Logging level")
    data_dir: str = Field(default="./data", description="Data directory path")


def load_config(config_path: Optional[Path] = None) -> SystemConfig:
    """Load configuration from file or environment variables."""
    if config_path and config_path.exists():
        with open(config_path, 'r') as f:
            config_data = yaml.safe_load(f)
        return SystemConfig(**config_data)
    
    # Load from environment variables
    config = SystemConfig()
    
    # OpenAI settings from environment
    if os.getenv("OPENAI_API_KEY"):
        config.openai.api_key = os.getenv("OPENAI_API_KEY")
    if os.getenv("OPENAI_MODEL"):
        config.openai.model = os.getenv("OPENAI_MODEL")
    if os.getenv("OPENAI_EMBEDDING_MODEL"):
        config.openai.embedding_model = os.getenv("OPENAI_EMBEDDING_MODEL")
    
    return config


def save_config(config: SystemConfig, config_path: Path) -> None:
    """Save configuration to file."""
    config_dict = config.model_dump(exclude_none=True)
    with open(config_path, 'w') as f:
        yaml.dump(config_dict, f, default_flow_style=False, indent=2)
