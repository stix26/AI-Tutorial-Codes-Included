"""Command-line interface for the Advanced Agentic AI System."""
import asyncio
import os
import sys
from pathlib import Path
from typing import Optional
import click
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.syntax import Syntax
from rich.progress import Progress, SpinnerColumn, TextColumn
import json
import yaml

from .config import SystemConfig, load_config, save_config
from .agent import AdvancedAgenticAI
import structlog

# Setup console for rich output
console = Console()

# Setup structured logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    wrapper_class=structlog.stdlib.BoundLogger,
    cache_logger_on_first_use=True,
)


@click.group()
@click.option('--config', '-c', type=click.Path(exists=True), help='Configuration file path')
@click.option('--api-key', envvar='OPENAI_API_KEY', help='OpenAI API key')
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose logging')
@click.pass_context
def cli(ctx, config, api_key, verbose):
    """Advanced Self-Evaluating Agentic AI System
    
    A comprehensive RAG-based agent with self-evaluation capabilities,
    advanced knowledge management, and robust evaluation metrics.
    """
    # Setup logging level
    if verbose:
        import logging
        logging.basicConfig(level=logging.INFO)
    
    # Load configuration
    config_path = Path(config) if config else None
    system_config = load_config(config_path)
    
    # Set API key if provided
    if api_key:
        system_config.openai.api_key = api_key
    elif not system_config.openai.api_key:
        api_key = click.prompt('Enter OpenAI API key', hide_input=True)
        system_config.openai.api_key = api_key
    
    # Store config in context
    ctx.ensure_object(dict)
    ctx.obj['config'] = system_config
    ctx.obj['verbose'] = verbose


@cli.command()
@click.option('--output', '-o', type=click.Path(), default='config.yaml', 
              help='Output configuration file path')
@click.pass_context
def init_config(ctx, output):
    """Initialize a new configuration file."""
    try:
        config = SystemConfig()
        save_config(config, Path(output))
        
        console.print(f"✅ Configuration file created: {output}", style="green")
        console.print("Edit the file to customize your settings.", style="cyan")
        
    except Exception as e:
        console.print(f"❌ Failed to create configuration: {e}", style="red")
        sys.exit(1)


@cli.command()
@click.argument('query', required=False)
@click.option('--interactive', '-i', is_flag=True, help='Start interactive mode')
@click.option('--session-id', help='Session identifier')
@click.option('--export', type=click.Path(), help='Export session to file')
@click.pass_context
def chat(ctx, query, interactive, session_id, export):
    """Chat with the agentic AI system."""
    config = ctx.obj['config']
    verbose = ctx.obj['verbose']
    
    try:
        # Initialize the AI system
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task("Initializing AI system...", total=None)
            ai_system = AdvancedAgenticAI(config)
            progress.remove_task(task)
        
        # Start session
        session_id = ai_system.start_session(session_id)
        console.print(f"🚀 Started session: {session_id}", style="green")
        
        if interactive or not query:
            _interactive_chat(ai_system, verbose)
        else:
            # Single query mode
            asyncio.run(_process_single_query(ai_system, query, verbose))
        
        # Export session if requested
        if export:
            ai_system.export_session(export)
            console.print(f"💾 Session exported to: {export}", style="green")
            
    except Exception as e:
        console.print(f"❌ Error: {e}", style="red")
        if verbose:
            console.print_exception()
        sys.exit(1)


def _interactive_chat(ai_system: AdvancedAgenticAI, verbose: bool = False):
    """Interactive chat mode."""
    console.print(Panel.fit(
        "🤖 Advanced Agentic AI System\n"
        "Type 'help' for commands, 'quit' to exit",
        title="Interactive Mode",
        style="cyan"
    ))
    
    while True:
        try:
            query = console.input("\n[bold cyan]You:[/bold cyan] ")
            
            if query.lower() in ['quit', 'exit', 'q']:
                console.print("👋 Goodbye!", style="green")
                break
            elif query.lower() == 'help':
                _show_help()
                continue
            elif query.lower() == 'stats':
                _show_stats(ai_system)
                continue
            elif query.lower().startswith('add_knowledge'):
                _add_knowledge_interactive(ai_system, query)
                continue
            elif not query.strip():
                continue
            
            # Process query
            with Progress(
                SpinnerColumn(),
                TextColumn("[progress.description]{task.description}"),
                transient=True,
            ) as progress:
                task = progress.add_task("Processing query...", total=None)
                response = asyncio.run(ai_system.process_query(query))
                progress.remove_task(task)
            
            # Display response
            _display_response(response, verbose)
            
        except KeyboardInterrupt:
            console.print("\n👋 Goodbye!", style="green")
            break
        except Exception as e:
            console.print(f"❌ Error processing query: {e}", style="red")
            if verbose:
                console.print_exception()


async def _process_single_query(ai_system: AdvancedAgenticAI, query: str, verbose: bool = False):
    """Process a single query."""
    console.print(f"[bold cyan]Query:[/bold cyan] {query}")
    
    response = await ai_system.process_query(query)
    _display_response(response, verbose)


def _display_response(response, verbose: bool = False):
    """Display agent response with formatting."""
    # Main response
    console.print(f"\n[bold green]Agent:[/bold green]")
    console.print(Panel(response.response, style="green", expand=False))
    
    if verbose and response.evaluation:
        # Evaluation details
        eval_table = Table(title="Evaluation Metrics")
        eval_table.add_column("Metric", style="cyan")
        eval_table.add_column("Score", style="yellow")
        eval_table.add_column("Status", style="green" if response.evaluation.passed_thresholds else "red")
        
        eval_table.add_row("Faithfulness", f"{response.evaluation.faithfulness_score:.2f}", "✅" if response.evaluation.faithfulness_score >= 0.7 else "❌")
        eval_table.add_row("Relevancy", f"{response.evaluation.relevancy_score:.2f}", "✅" if response.evaluation.relevancy_score >= 0.7 else "❌")
        eval_table.add_row("Answer Quality", f"{response.evaluation.answer_relevancy_score:.2f}", "✅" if response.evaluation.answer_relevancy_score >= 0.7 else "❌")
        eval_table.add_row("Context Quality", f"{response.evaluation.context_relevancy_score:.2f}", "✅" if response.evaluation.context_relevancy_score >= 0.7 else "❌")
        eval_table.add_row("Overall", f"{response.evaluation.overall_score:.2f}", "✅" if response.evaluation.passed_thresholds else "❌")
        
        console.print(eval_table)
        
        # Performance info
        console.print(f"⏱️ Processing time: {response.total_time:.2f}s")
        if response.evaluation.detailed_feedback.get('recommendations'):
            console.print("💡 Recommendations:")
            for rec in response.evaluation.detailed_feedback['recommendations']:
                console.print(f"  • {rec}", style="yellow")


def _show_help():
    """Show help information."""
    help_text = """
Available commands:
  
  📝 Regular queries: Just type your question
  📊 stats: Show knowledge base and session statistics
  🧠 add_knowledge <text>: Add knowledge to the system
  ❓ help: Show this help message
  🚪 quit/exit/q: Exit the program
  
Tips:
  • The system will automatically retrieve evidence and evaluate responses
  • Use detailed, specific questions for best results
  • The system learns from new knowledge you add during the session
    """
    console.print(Panel(help_text, title="Help", style="cyan"))


def _show_stats(ai_system: AdvancedAgenticAI):
    """Show system statistics."""
    # Knowledge base stats
    kb_stats = ai_system.knowledge_base.get_stats()
    kb_table = Table(title="Knowledge Base Statistics")
    kb_table.add_column("Metric", style="cyan")
    kb_table.add_column("Value", style="yellow")
    
    kb_table.add_row("Total Documents", str(kb_stats.total_documents))
    kb_table.add_row("Total Nodes", str(kb_stats.total_nodes))
    kb_table.add_row("Last Updated", kb_stats.last_updated.strftime('%Y-%m-%d %H:%M:%S'))
    kb_table.add_row("Index Size", f"{kb_stats.index_size / 1024:.1f} KB")
    
    console.print(kb_table)
    
    # Session stats
    session_stats = ai_system.get_session_stats()
    if session_stats:
        session_table = Table(title="Session Statistics")
        session_table.add_column("Metric", style="cyan")
        session_table.add_column("Value", style="yellow")
        
        session_table.add_row("Session ID", session_stats['session_id'])
        session_table.add_row("Queries Processed", str(session_stats['queries_processed']))
        session_table.add_row("Successful Responses", str(session_stats['successful_responses']))
        session_table.add_row("Average Score", f"{session_stats['average_score']:.2f}")
        session_table.add_row("Total Eval Time", f"{session_stats['total_evaluation_time']:.2f}s")
        
        console.print(session_table)


def _add_knowledge_interactive(ai_system: AdvancedAgenticAI, command: str):
    """Add knowledge interactively."""
    try:
        # Parse command - simple implementation
        parts = command.split(' ', 1)
        if len(parts) > 1:
            text = parts[1]
        else:
            text = console.input("Enter text to add: ")
        
        title = console.input("Enter title (optional): ").strip()
        tags = console.input("Enter tags (comma-separated, optional): ").strip()
        
        tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()] if tags else []
        
        ai_system.add_knowledge_from_text(text, title, tag_list)
        console.print("✅ Knowledge added successfully!", style="green")
        
    except Exception as e:
        console.print(f"❌ Failed to add knowledge: {e}", style="red")


@cli.command()
@click.argument('directory', type=click.Path(exists=True))
@click.option('--tags', help='Comma-separated tags for the documents')
@click.pass_context
def load_documents(ctx, directory, tags):
    """Load documents from a directory into the knowledge base."""
    config = ctx.obj['config']
    
    try:
        ai_system = AdvancedAgenticAI(config)
        
        tag_list = [tag.strip() for tag in tags.split(",")] if tags else None
        
        with Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            transient=True,
        ) as progress:
            task = progress.add_task(f"Loading documents from {directory}...", total=None)
            ai_system.knowledge_base.load_from_directory(directory, tag_list)
            progress.remove_task(task)
        
        console.print(f"✅ Documents loaded from: {directory}", style="green")
        
        # Show stats
        stats = ai_system.knowledge_base.get_stats()
        console.print(f"📚 Total documents: {stats.total_documents}", style="cyan")
        
    except Exception as e:
        console.print(f"❌ Failed to load documents: {e}", style="red")
        sys.exit(1)


@cli.command()
@click.argument('query')
@click.option('--top-k', '-k', default=5, help='Number of results to return')
@click.pass_context
def search(ctx, query, top_k):
    """Search the knowledge base."""
    config = ctx.obj['config']
    
    try:
        ai_system = AdvancedAgenticAI(config)
        results = ai_system.knowledge_base.search(query, top_k)
        
        if not results:
            console.print("No results found.", style="yellow")
            return
        
        console.print(f"[bold cyan]Search Results for:[/bold cyan] {query}\n")
        
        for i, result in enumerate(results, 1):
            score = result.get('score', 0.0)
            content = result['content'][:300] + "..." if len(result['content']) > 300 else result['content']
            source = result.get('metadata', {}).get('title', 'Unknown')
            
            panel = Panel(
                content,
                title=f"Result {i} (Score: {score:.2f}) - {source}",
                style="blue"
            )
            console.print(panel)
        
    except Exception as e:
        console.print(f"❌ Search failed: {e}", style="red")
        sys.exit(1)


@cli.command()
@click.pass_context
def stats(ctx):
    """Show system statistics."""
    config = ctx.obj['config']
    
    try:
        ai_system = AdvancedAgenticAI(config)
        _show_stats(ai_system)
        
    except Exception as e:
        console.print(f"❌ Failed to get statistics: {e}", style="red")
        sys.exit(1)


if __name__ == '__main__':
    cli()
