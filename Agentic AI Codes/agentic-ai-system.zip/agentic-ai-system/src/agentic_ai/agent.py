"""Advanced self-evaluating agentic AI system."""
import asyncio
import structlog
from typing import Dict, Any, List, Optional, Callable
from datetime import datetime
from dataclasses import dataclass, asdict
import json

from llama_index.core import Settings
from llama_index.llms.openai import OpenAI
from llama_index.embeddings.openai import OpenAIEmbedding
from llama_index.core.tools import FunctionTool
from llama_index.core.agent import ReActAgent

from .config import SystemConfig
from .knowledge_base import AdvancedKnowledgeBase
from .evaluation import create_evaluation_tools, EvaluationResult

logger = structlog.get_logger()


@dataclass
class AgentResponse:
    """Enhanced agent response with evaluation and metadata."""
    query: str
    response: str
    evaluation: Optional[EvaluationResult]
    retrieved_evidence: List[str]
    iteration_count: int
    revision_count: int
    total_time: float
    timestamp: datetime
    metadata: Dict[str, Any]


@dataclass
class AgentSession:
    """Agent session tracking."""
    session_id: str
    start_time: datetime
    queries_processed: int
    total_evaluation_time: float
    average_score: float
    successful_responses: int


class AdvancedAgenticAI:
    """Advanced self-evaluating agentic AI system."""
    
    def __init__(self, config: SystemConfig):
        self.config = config
        self.logger = logger.bind(component="agent")
        
        # Configure LlamaIndex settings
        self._setup_llm()
        
        # Initialize knowledge base
        self.knowledge_base = AdvancedKnowledgeBase(
            config.knowledge_base.model_dump(),
            config.data_dir
        )
        
        # Initialize evaluation tools
        self.evaluation_tools = create_evaluation_tools(
            Settings.llm,
            config.evaluation.model_dump()
        )
        
        # Create agent tools
        self.tools = self._create_tools()
        
        # Initialize agent
        self.agent = self._create_agent()
        
        # Session tracking
        self.current_session: Optional[AgentSession] = None
        self.response_history: List[AgentResponse] = []
        
        self.logger.info("Advanced Agentic AI system initialized")
    
    def _setup_llm(self) -> None:
        """Setup LLM and embedding models."""
        try:
            # Validate API key
            if not self.config.openai.api_key:
                raise ValueError("OpenAI API key is required")
            
            # Configure LLM
            Settings.llm = OpenAI(
                model=self.config.openai.model,
                temperature=self.config.openai.temperature,
                max_tokens=self.config.openai.max_tokens,
                api_key=self.config.openai.api_key
            )
            
            # Configure embedding model
            Settings.embed_model = OpenAIEmbedding(
                model=self.config.openai.embedding_model,
                api_key=self.config.openai.api_key
            )
            
            self.logger.info(
                "LLM configured",
                model=self.config.openai.model,
                embedding_model=self.config.openai.embedding_model
            )
            
        except Exception as e:
            self.logger.error("Failed to setup LLM", error=str(e))
            raise
    
    def _create_tools(self) -> List[FunctionTool]:
        """Create tools for the agent."""
        tools = []
        
        # Evidence retrieval tool
        def retrieve_evidence(query: str) -> str:
            """Retrieve relevant evidence from the knowledge base for a given query.
            
            Args:
                query: The query to search for
                
            Returns:
                Formatted evidence with source references
            """
            try:
                results = self.knowledge_base.search(query)
                if not results:
                    return "No relevant evidence found."
                
                evidence_list = []
                for i, result in enumerate(results):
                    content = result['content'][:400]  # Limit content length
                    score = result.get('score', 0.0)
                    source = result.get('metadata', {}).get('title', 'Unknown')
                    evidence_list.append(
                        f"[{i+1}] (Score: {score:.2f}, Source: {source})\n{content}"
                    )
                
                return "\n\n".join(evidence_list)
                
            except Exception as e:
                self.logger.error("Evidence retrieval failed", error=str(e))
                return f"Error retrieving evidence: {str(e)}"
        
        # Answer scoring tool
        def score_answer(query: str, answer: str) -> str:
            """Score an answer using comprehensive evaluation metrics.
            
            Args:
                query: The original query
                answer: The answer to evaluate
                
            Returns:
                Detailed evaluation scores and feedback
            """
            try:
                # This is a synchronous wrapper for the async function
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    result = loop.run_until_complete(
                        self.evaluation_tools["score_answer"](
                            query, answer, self.knowledge_base.query_engine
                        )
                    )
                    return result
                finally:
                    loop.close()
                    
            except Exception as e:
                self.logger.error("Answer scoring failed", error=str(e))
                return f"Error scoring answer: {str(e)}"
        
        # Knowledge base stats tool
        def get_knowledge_stats() -> str:
            """Get statistics about the knowledge base.
            
            Returns:
                Formatted knowledge base statistics
            """
            try:
                stats = self.knowledge_base.get_stats()
                return (
                    f"Knowledge Base Statistics:\n"
                    f"- Total Documents: {stats.total_documents}\n"
                    f"- Total Nodes: {stats.total_nodes}\n"
                    f"- Last Updated: {stats.last_updated.strftime('%Y-%m-%d %H:%M:%S')}\n"
                    f"- Index Size: {stats.index_size / 1024:.1f} KB\n"
                    f"- Document Types: {dict(stats.document_types)}"
                )
            except Exception as e:
                self.logger.error("Failed to get knowledge stats", error=str(e))
                return f"Error getting statistics: {str(e)}"
        
        # Add knowledge tool
        def add_knowledge(text: str, title: str = "", tags: str = "") -> str:
            """Add new knowledge to the knowledge base.
            
            Args:
                text: The text content to add
                title: Optional title for the document
                tags: Comma-separated tags
                
            Returns:
                Confirmation message
            """
            try:
                tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]
                titles = [title] if title else None
                
                self.knowledge_base.add_text_documents(
                    texts=[text],
                    titles=titles,
                    tags=tag_list
                )
                
                return f"Successfully added knowledge: '{title or 'Untitled'}'"
                
            except Exception as e:
                self.logger.error("Failed to add knowledge", error=str(e))
                return f"Error adding knowledge: {str(e)}"
        
        # Create function tools
        tools = [
            FunctionTool.from_defaults(fn=retrieve_evidence),
            FunctionTool.from_defaults(fn=score_answer),
            FunctionTool.from_defaults(fn=get_knowledge_stats),
            FunctionTool.from_defaults(fn=add_knowledge)
        ]
        
        return tools
    
    def _create_agent(self) -> ReActAgent:
        """Create the ReAct agent with enhanced capabilities."""
        system_prompt = f"""
You are an advanced self-evaluating agentic AI system. Your primary goal is to provide accurate, 
well-grounded responses while continuously evaluating and improving your own performance.

CORE PRINCIPLES:
1. ALWAYS retrieve relevant evidence before answering any question
2. Produce structured, comprehensive answers grounded in retrieved evidence
3. Evaluate your answers using the scoring tools and revise if quality is low
4. Be transparent about your reasoning process and any limitations

WORKFLOW:
1. RETRIEVE: Use retrieve_evidence to gather relevant information
2. ANSWER: Synthesize information into a comprehensive response
3. EVALUATE: Use score_answer to assess response quality
4. REVISE: If scores are below threshold ({self.config.evaluation.faithfulness_threshold}), 
   revise your response once based on the evaluation feedback

QUALITY STANDARDS:
- Faithfulness Score: ≥ {self.config.evaluation.faithfulness_threshold}
- Relevancy Score: ≥ {self.config.evaluation.relevancy_threshold}
- Overall Quality: ≥ {self.config.evaluation.quality_threshold}

If you cannot find relevant evidence or your evaluation scores are consistently low, 
acknowledge this limitation and explain what information would be needed for a better response.

Available tools:
- retrieve_evidence: Search knowledge base for relevant information
- score_answer: Evaluate response quality with detailed metrics
- get_knowledge_stats: View knowledge base statistics
- add_knowledge: Add new information to knowledge base

Always strive for excellence while being honest about uncertainties.
"""
        
        return ReActAgent.from_tools(
            tools=self.tools,
            llm=Settings.llm,
            verbose=self.config.agent.verbose,
            system_prompt=system_prompt,
            max_iterations=self.config.agent.max_iterations
        )
    
    def start_session(self, session_id: Optional[str] = None) -> str:
        """Start a new agent session."""
        session_id = session_id or f"session_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        self.current_session = AgentSession(
            session_id=session_id,
            start_time=datetime.now(),
            queries_processed=0,
            total_evaluation_time=0.0,
            average_score=0.0,
            successful_responses=0
        )
        
        self.logger.info("Started new session", session_id=session_id)
        return session_id
    
    async def process_query(
        self, 
        query: str, 
        context: Optional[Dict[str, Any]] = None
    ) -> AgentResponse:
        """Process a query with the agentic AI system."""
        start_time = asyncio.get_event_loop().time()
        
        try:
            self.logger.info("Processing query", query=query[:100])
            
            # Initialize response tracking
            retrieved_evidence = []
            evaluation_result = None
            iteration_count = 0
            revision_count = 0
            
            # Run agent
            response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.agent.chat(query)
            )
            
            # Extract response text
            response_text = str(response)
            
            # Try to extract evidence (if agent used retrieve_evidence)
            # This is a simplified extraction - in practice, you'd want to 
            # instrument the tools to capture this information
            try:
                evidence_results = self.knowledge_base.search(query)
                retrieved_evidence = [r['content'][:200] for r in evidence_results[:3]]
            except:
                pass
            
            # Perform final evaluation
            try:
                contexts = [node.node.get_content() for node in 
                           self.knowledge_base.query(query).source_nodes or []]
                evaluation_result = await self.evaluation_tools["evaluator"].evaluate_response(
                    query, response_text, contexts
                )
            except Exception as e:
                self.logger.warning("Final evaluation failed", error=str(e))
            
            total_time = asyncio.get_event_loop().time() - start_time
            
            # Create response object
            agent_response = AgentResponse(
                query=query,
                response=response_text,
                evaluation=evaluation_result,
                retrieved_evidence=retrieved_evidence,
                iteration_count=iteration_count,
                revision_count=revision_count,
                total_time=total_time,
                timestamp=datetime.now(),
                metadata=context or {}
            )
            
            # Update session tracking
            if self.current_session:
                self.current_session.queries_processed += 1
                if evaluation_result:
                    self.current_session.total_evaluation_time += evaluation_result.evaluation_time
                    # Update running average
                    current_avg = self.current_session.average_score
                    new_score = evaluation_result.overall_score if evaluation_result else 0.5
                    count = self.current_session.queries_processed
                    self.current_session.average_score = (current_avg * (count - 1) + new_score) / count
                    
                    if evaluation_result.passed_thresholds:
                        self.current_session.successful_responses += 1
            
            # Add to history
            self.response_history.append(agent_response)
            
            self.logger.info(
                "Query processed successfully",
                response_length=len(response_text),
                total_time=total_time,
                evaluation_score=evaluation_result.overall_score if evaluation_result else None
            )
            
            return agent_response
            
        except Exception as e:
            self.logger.error("Query processing failed", query=query, error=str(e))
            raise
    
    def get_session_stats(self) -> Optional[Dict[str, Any]]:
        """Get current session statistics."""
        if not self.current_session:
            return None
        
        return asdict(self.current_session)
    
    def get_response_history(self, limit: Optional[int] = None) -> List[Dict[str, Any]]:
        """Get response history."""
        history = self.response_history[-limit:] if limit else self.response_history
        
        # Convert to JSON-serializable format
        serializable_history = []
        for response in history:
            response_dict = asdict(response)
            response_dict['timestamp'] = response.timestamp.isoformat()
            if response.evaluation:
                response_dict['evaluation'] = asdict(response.evaluation)
                response_dict['evaluation']['evaluation_time'] = response.evaluation.evaluation_time
            serializable_history.append(response_dict)
        
        return serializable_history
    
    def add_knowledge_from_text(
        self, 
        text: str, 
        title: str = "", 
        tags: List[str] = None
    ) -> None:
        """Add knowledge to the system."""
        self.knowledge_base.add_text_documents(
            texts=[text],
            titles=[title] if title else None,
            tags=tags or []
        )
        self.logger.info("Added knowledge", title=title, text_length=len(text))
    
    def export_session(self, filepath: str) -> None:
        """Export session data to file."""
        try:
            session_data = {
                "session": self.get_session_stats(),
                "response_history": self.get_response_history(),
                "knowledge_base_stats": asdict(self.knowledge_base.get_stats()),
                "export_timestamp": datetime.now().isoformat()
            }
            
            # Handle datetime serialization
            if session_data["session"]:
                session_data["session"]["start_time"] = self.current_session.start_time.isoformat()
            
            kb_stats = session_data["knowledge_base_stats"]
            kb_stats["last_updated"] = kb_stats["last_updated"].isoformat()
            
            with open(filepath, 'w') as f:
                json.dump(session_data, f, indent=2)
                
            self.logger.info("Session exported", filepath=filepath)
            
        except Exception as e:
            self.logger.error("Session export failed", error=str(e))
            raise
