"""Advanced Self-Evaluating Agentic AI System

A comprehensive RAG-based agent with self-evaluation capabilities,
advanced knowledge management, and robust evaluation metrics.
"""

from .config import SystemConfig, load_config, save_config
from .agent import AdvancedAgenticAI, AgentResponse, AgentSession
from .knowledge_base import AdvancedKnowledgeBase, DocumentMetadata, KnowledgeBaseStats
from .evaluation import AdvancedEvaluator, EvaluationResult, create_evaluation_tools

__version__ = "1.0.0"
__author__ = "Advanced AI Research"
__description__ = "Self-Evaluating Agentic AI System with LlamaIndex and OpenAI"

__all__ = [
    'SystemConfig',
    'load_config', 
    'save_config',
    'AdvancedAgenticAI',
    'AgentResponse',
    'AgentSession',
    'AdvancedKnowledgeBase',
    'DocumentMetadata',
    'KnowledgeBaseStats',
    'AdvancedEvaluator',
    'EvaluationResult',
    'create_evaluation_tools'
]
