"""Advanced evaluation system for agentic AI responses."""
import asyncio
import structlog
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass
from llama_index.core.evaluation import (
    FaithfulnessEvaluator, 
    RelevancyEvaluator,
    AnswerRelevancyEvaluator,
    ContextRelevancyEvaluator
)
from llama_index.core.llms import LLM
from llama_index.core.schema import QueryBundle
from tenacity import retry, stop_after_attempt, wait_exponential

logger = structlog.get_logger()


@dataclass
class EvaluationResult:
    """Comprehensive evaluation result."""
    faithfulness_score: float
    relevancy_score: float
    answer_relevancy_score: float
    context_relevancy_score: float
    overall_score: float
    passed_thresholds: bool
    detailed_feedback: Dict[str, Any]
    evaluation_time: float


class AdvancedEvaluator:
    """Advanced evaluation system with multiple metrics."""
    
    def __init__(self, llm: LLM, config: Dict[str, Any]):
        self.llm = llm
        self.config = config
        self.logger = logger.bind(component="evaluator")
        
        # Initialize evaluators
        self.faithfulness_eval = FaithfulnessEvaluator(llm=llm)
        self.relevancy_eval = RelevancyEvaluator(llm=llm)
        self.answer_relevancy_eval = AnswerRelevancyEvaluator(llm=llm)
        self.context_relevancy_eval = ContextRelevancyEvaluator(llm=llm)
        
        # Thresholds
        self.faithfulness_threshold = config.get('faithfulness_threshold', 0.7)
        self.relevancy_threshold = config.get('relevancy_threshold', 0.7)
        self.quality_threshold = config.get('quality_threshold', 0.7)
        
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=4, max=10)
    )
    async def evaluate_response(
        self, 
        query: str, 
        response: str, 
        contexts: List[str],
        metadata: Optional[Dict[str, Any]] = None
    ) -> EvaluationResult:
        """Perform comprehensive evaluation of a response."""
        start_time = asyncio.get_event_loop().time()
        
        try:
            self.logger.info("Starting response evaluation", query=query[:100])
            
            # Run evaluations concurrently for better performance
            tasks = []
            
            if self.config.get('enable_faithfulness', True):
                tasks.append(self._evaluate_faithfulness(query, response, contexts))
            else:
                tasks.append(asyncio.create_task(self._return_default_score(1.0)))
                
            if self.config.get('enable_relevancy', True):
                tasks.append(self._evaluate_relevancy(query, response, contexts))
            else:
                tasks.append(asyncio.create_task(self._return_default_score(1.0)))
                
            if self.config.get('enable_answer_quality', True):
                tasks.append(self._evaluate_answer_relevancy(query, response))
                tasks.append(self._evaluate_context_relevancy(query, contexts))
            else:
                tasks.append(asyncio.create_task(self._return_default_score(1.0)))
                tasks.append(asyncio.create_task(self._return_default_score(1.0)))
            
            # Execute all evaluations
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Handle exceptions
            scores = []
            for i, result in enumerate(results):
                if isinstance(result, Exception):
                    self.logger.warning(f"Evaluation {i} failed", error=str(result))
                    scores.append(0.5)  # Default middle score on failure
                else:
                    scores.append(result)
            
            faithfulness_score, relevancy_score, answer_relevancy_score, context_relevancy_score = scores
            
            # Calculate overall score with weighted average
            weights = [0.3, 0.3, 0.25, 0.15]  # Prioritize faithfulness and relevancy
            overall_score = sum(score * weight for score, weight in zip(scores, weights))
            
            # Check thresholds
            passed_thresholds = (
                faithfulness_score >= self.faithfulness_threshold and
                relevancy_score >= self.relevancy_threshold and
                overall_score >= self.quality_threshold
            )
            
            # Generate detailed feedback
            detailed_feedback = self._generate_feedback(
                faithfulness_score, relevancy_score, 
                answer_relevancy_score, context_relevancy_score,
                passed_thresholds
            )
            
            evaluation_time = asyncio.get_event_loop().time() - start_time
            
            result = EvaluationResult(
                faithfulness_score=faithfulness_score,
                relevancy_score=relevancy_score,
                answer_relevancy_score=answer_relevancy_score,
                context_relevancy_score=context_relevancy_score,
                overall_score=overall_score,
                passed_thresholds=passed_thresholds,
                detailed_feedback=detailed_feedback,
                evaluation_time=evaluation_time
            )
            
            self.logger.info(
                "Evaluation completed",
                overall_score=overall_score,
                passed_thresholds=passed_thresholds,
                evaluation_time=evaluation_time
            )
            
            return result
            
        except Exception as e:
            self.logger.error("Evaluation failed", error=str(e))
            raise
    
    async def _return_default_score(self, score: float) -> float:
        """Return a default score asynchronously."""
        return score
    
    async def _evaluate_faithfulness(self, query: str, response: str, contexts: List[str]) -> float:
        """Evaluate faithfulness of the response to the contexts."""
        try:
            eval_result = await asyncio.get_event_loop().run_in_executor(
                None, 
                lambda: self.faithfulness_eval.evaluate(
                    query=query, response=response, contexts=contexts
                )
            )
            return float(eval_result.score) if eval_result.score is not None else 0.5
        except Exception as e:
            self.logger.warning("Faithfulness evaluation failed", error=str(e))
            return 0.5
    
    async def _evaluate_relevancy(self, query: str, response: str, contexts: List[str]) -> float:
        """Evaluate relevancy of the response to the query."""
        try:
            eval_result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.relevancy_eval.evaluate(
                    query=query, response=response, contexts=contexts
                )
            )
            return float(eval_result.score) if eval_result.score is not None else 0.5
        except Exception as e:
            self.logger.warning("Relevancy evaluation failed", error=str(e))
            return 0.5
    
    async def _evaluate_answer_relevancy(self, query: str, response: str) -> float:
        """Evaluate how relevant the answer is to the query."""
        try:
            eval_result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.answer_relevancy_eval.evaluate(
                    query=query, response=response
                )
            )
            return float(eval_result.score) if eval_result.score is not None else 0.5
        except Exception as e:
            self.logger.warning("Answer relevancy evaluation failed", error=str(e))
            return 0.5
    
    async def _evaluate_context_relevancy(self, query: str, contexts: List[str]) -> float:
        """Evaluate how relevant the retrieved contexts are to the query."""
        try:
            eval_result = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self.context_relevancy_eval.evaluate(
                    query=query, contexts=contexts
                )
            )
            return float(eval_result.score) if eval_result.score is not None else 0.5
        except Exception as e:
            self.logger.warning("Context relevancy evaluation failed", error=str(e))
            return 0.5
    
    def _generate_feedback(
        self, 
        faithfulness: float, 
        relevancy: float,
        answer_relevancy: float,
        context_relevancy: float,
        passed: bool
    ) -> Dict[str, Any]:
        """Generate detailed feedback based on evaluation scores."""
        feedback = {
            "summary": "PASSED" if passed else "FAILED",
            "scores": {
                "faithfulness": faithfulness,
                "relevancy": relevancy,
                "answer_relevancy": answer_relevancy,
                "context_relevancy": context_relevancy
            },
            "recommendations": []
        }
        
        if faithfulness < self.faithfulness_threshold:
            feedback["recommendations"].append(
                f"Improve faithfulness (current: {faithfulness:.2f}, threshold: {self.faithfulness_threshold}). "
                "Ensure response stays grounded in the provided context."
            )
        
        if relevancy < self.relevancy_threshold:
            feedback["recommendations"].append(
                f"Improve relevancy (current: {relevancy:.2f}, threshold: {self.relevancy_threshold}). "
                "Make sure the response directly addresses the query."
            )
        
        if answer_relevancy < self.quality_threshold:
            feedback["recommendations"].append(
                f"Improve answer quality (current: {answer_relevancy:.2f}, threshold: {self.quality_threshold}). "
                "Provide more comprehensive and well-structured responses."
            )
        
        if context_relevancy < 0.6:
            feedback["recommendations"].append(
                "Consider improving retrieval quality. Retrieved contexts may not be sufficiently relevant."
            )
        
        return feedback


def create_evaluation_tools(llm: LLM, config: Dict[str, Any]) -> Dict[str, Any]:
    """Create evaluation tools for the agent."""
    evaluator = AdvancedEvaluator(llm, config)
    
    def retrieve_evidence(query: str, query_engine) -> str:
        """Retrieve evidence for a given query."""
        try:
            response = query_engine.query(query)
            evidence = []
            for i, node in enumerate(response.source_nodes or []):
                content = node.node.get_content()[:300]
                evidence.append(f"[{i+1}] {content}")
            return "\n".join(evidence) if evidence else "No evidence found."
        except Exception as e:
            logger.error("Evidence retrieval failed", error=str(e))
            return f"Error retrieving evidence: {str(e)}"
    
    async def score_answer(query: str, answer: str, query_engine) -> str:
        """Score an answer using comprehensive evaluation."""
        try:
            response = query_engine.query(query)
            contexts = [node.node.get_content() for node in response.source_nodes or []]
            
            eval_result = await evaluator.evaluate_response(query, answer, contexts)
            
            return (
                f"Overall Score: {eval_result.overall_score:.2f}\n"
                f"Faithfulness: {eval_result.faithfulness_score:.2f}\n"
                f"Relevancy: {eval_result.relevancy_score:.2f}\n"
                f"Answer Quality: {eval_result.answer_relevancy_score:.2f}\n"
                f"Context Quality: {eval_result.context_relevancy_score:.2f}\n"
                f"Status: {eval_result.detailed_feedback['summary']}\n"
                f"Recommendations: {'; '.join(eval_result.detailed_feedback.get('recommendations', []))}"
            )
        except Exception as e:
            logger.error("Answer scoring failed", error=str(e))
            return f"Error scoring answer: {str(e)}"
    
    return {
        "retrieve_evidence": retrieve_evidence,
        "score_answer": score_answer,
        "evaluator": evaluator
    }
