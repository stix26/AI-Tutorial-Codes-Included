"""Advanced knowledge base management system."""
import os
import json
import pickle
import structlog
from pathlib import Path
from typing import Dict, Any, List, Optional, Union
from datetime import datetime
from dataclasses import dataclass, asdict

from llama_index.core import (
    Document, 
    VectorStoreIndex, 
    SimpleDirectoryReader,
    StorageContext,
    load_index_from_storage
)
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.schema import BaseNode
from llama_index.core.retrievers import VectorIndexRetriever
from llama_index.core.query_engine import RetrieverQueryEngine

logger = structlog.get_logger()


@dataclass
class DocumentMetadata:
    """Metadata for documents in the knowledge base."""
    id: str
    title: str
    source: str
    created_at: datetime
    updated_at: datetime
    tags: List[str]
    document_type: str
    size: int
    checksum: str


@dataclass
class KnowledgeBaseStats:
    """Statistics about the knowledge base."""
    total_documents: int
    total_nodes: int
    last_updated: datetime
    index_size: int
    document_types: Dict[str, int]


class AdvancedKnowledgeBase:
    """Advanced knowledge base with document management and retrieval."""
    
    def __init__(self, config: Dict[str, Any], data_dir: str = "./data"):
        self.config = config
        self.data_dir = Path(data_dir)
        self.index_dir = self.data_dir / "index"
        self.metadata_file = self.data_dir / "metadata.json"
        self.logger = logger.bind(component="knowledge_base")
        
        # Ensure directories exist
        self.data_dir.mkdir(exist_ok=True)
        self.index_dir.mkdir(exist_ok=True)
        
        # Document parser
        self.node_parser = SentenceSplitter(
            chunk_size=config.get('chunk_size', 512),
            chunk_overlap=config.get('chunk_overlap', 50)
        )
        
        # Initialize components
        self.index: Optional[VectorStoreIndex] = None
        self.query_engine = None
        self.documents_metadata: Dict[str, DocumentMetadata] = {}
        
        # Load existing data
        self._load_metadata()
        self._load_or_create_index()
    
    def _load_metadata(self) -> None:
        """Load document metadata from storage."""
        try:
            if self.metadata_file.exists():
                with open(self.metadata_file, 'r') as f:
                    metadata_dict = json.load(f)
                    self.documents_metadata = {
                        doc_id: DocumentMetadata(**doc_data)
                        for doc_id, doc_data in metadata_dict.items()
                    }
                self.logger.info(
                    "Loaded metadata", 
                    document_count=len(self.documents_metadata)
                )
        except Exception as e:
            self.logger.warning("Failed to load metadata", error=str(e))
            self.documents_metadata = {}
    
    def _save_metadata(self) -> None:
        """Save document metadata to storage."""
        try:
            metadata_dict = {
                doc_id: asdict(metadata) 
                for doc_id, metadata in self.documents_metadata.items()
            }
            # Convert datetime objects to ISO format strings
            for doc_data in metadata_dict.values():
                doc_data['created_at'] = doc_data['created_at'].isoformat()
                doc_data['updated_at'] = doc_data['updated_at'].isoformat()
            
            with open(self.metadata_file, 'w') as f:
                json.dump(metadata_dict, f, indent=2)
                
        except Exception as e:
            self.logger.error("Failed to save metadata", error=str(e))
    
    def _load_or_create_index(self) -> None:
        """Load existing index or create a new one."""
        try:
            if (self.index_dir / "index_store.json").exists():
                # Load existing index
                storage_context = StorageContext.from_defaults(persist_dir=self.index_dir)
                self.index = load_index_from_storage(storage_context)
                self.logger.info("Loaded existing index")
            else:
                # Create new index with sample documents
                self._create_initial_index()
                
            # Create query engine
            retriever = VectorIndexRetriever(
                index=self.index,
                similarity_top_k=self.config.get('similarity_top_k', 4)
            )
            self.query_engine = RetrieverQueryEngine(retriever=retriever)
            
        except Exception as e:
            self.logger.error("Failed to load/create index", error=str(e))
            raise
    
    def _create_initial_index(self) -> None:
        """Create initial index with default knowledge."""
        default_texts = [
            "Reliable RAG systems separate retrieval, synthesis, and verification. "
            "Common failures include hallucination and shallow retrieval. "
            "Best practices include using multiple retrieval strategies and implementing "
            "robust evaluation metrics.",
            
            "RAG evaluation focuses on faithfulness, answer relevancy, and retrieval quality. "
            "Faithfulness measures how well the response is grounded in the retrieved context. "
            "Answer relevancy assesses how well the response addresses the query. "
            "Retrieval quality evaluates the relevance of retrieved documents.",
            
            "Tool-using agents require constrained tools, validation, and self-review loops. "
            "Constraints prevent harmful actions and ensure reliable behavior. "
            "Validation checks tool inputs and outputs for correctness. "
            "Self-review loops allow agents to evaluate and improve their own responses.",
            
            "A robust workflow follows retrieve, answer, evaluate, and revise steps. "
            "The retrieve step gathers relevant information from the knowledge base. "
            "The answer step synthesizes information into a coherent response. "
            "The evaluate step assesses response quality using multiple metrics. "
            "The revise step improves the response based on evaluation feedback.",
            
            "Advanced agentic AI systems implement multi-layered evaluation frameworks. "
            "These include real-time monitoring, batch evaluation, and human-in-the-loop validation. "
            "Monitoring tracks system performance and identifies potential issues. "
            "Batch evaluation provides comprehensive analysis of system behavior over time.",
            
            "Self-evaluating agents use metacognitive techniques to assess their own performance. "
            "This includes confidence scoring, uncertainty estimation, and error detection. "
            "Confidence scoring helps identify when the agent is uncertain about its response. "
            "Error detection mechanisms can flag potentially incorrect or harmful outputs."
        ]
        
        documents = []
        for i, text in enumerate(default_texts):
            doc_id = f"default_doc_{i+1}"
            doc = Document(
                text=text,
                doc_id=doc_id,
                metadata={
                    "source": "default",
                    "title": f"Default Knowledge {i+1}",
                    "created_at": datetime.now().isoformat()
                }
            )
            documents.append(doc)
            
            # Add metadata
            self.documents_metadata[doc_id] = DocumentMetadata(
                id=doc_id,
                title=f"Default Knowledge {i+1}",
                source="default",
                created_at=datetime.now(),
                updated_at=datetime.now(),
                tags=["default", "rag", "evaluation"],
                document_type="text",
                size=len(text),
                checksum=""
            )
        
        # Create index
        self.index = VectorStoreIndex.from_documents(
            documents,
            node_parser=self.node_parser
        )
        
        # Persist index
        self.index.storage_context.persist(persist_dir=self.index_dir)
        self._save_metadata()
        
        self.logger.info(
            "Created initial index", 
            document_count=len(documents)
        )
    
    def add_documents(
        self, 
        documents: List[Document], 
        tags: Optional[List[str]] = None
    ) -> None:
        """Add documents to the knowledge base."""
        try:
            if not documents:
                return
            
            # Add documents to index
            for doc in documents:
                self.index.insert(doc)
                
                # Add metadata
                doc_id = doc.doc_id or f"doc_{len(self.documents_metadata)}"
                self.documents_metadata[doc_id] = DocumentMetadata(
                    id=doc_id,
                    title=doc.metadata.get('title', f'Document {doc_id}'),
                    source=doc.metadata.get('source', 'unknown'),
                    created_at=datetime.now(),
                    updated_at=datetime.now(),
                    tags=tags or [],
                    document_type=doc.metadata.get('type', 'text'),
                    size=len(doc.text),
                    checksum=""
                )
            
            # Persist changes
            self.index.storage_context.persist(persist_dir=self.index_dir)
            self._save_metadata()
            
            self.logger.info(
                "Added documents to knowledge base", 
                count=len(documents)
            )
            
        except Exception as e:
            self.logger.error("Failed to add documents", error=str(e))
            raise
    
    def add_text_documents(
        self, 
        texts: List[str], 
        titles: Optional[List[str]] = None,
        tags: Optional[List[str]] = None
    ) -> None:
        """Add text documents to the knowledge base."""
        documents = []
        for i, text in enumerate(texts):
            title = titles[i] if titles and i < len(titles) else f"Text Document {i+1}"
            doc = Document(
                text=text,
                metadata={
                    "title": title,
                    "source": "text_input",
                    "created_at": datetime.now().isoformat()
                }
            )
            documents.append(doc)
        
        self.add_documents(documents, tags)
    
    def load_from_directory(
        self, 
        directory_path: Union[str, Path],
        tags: Optional[List[str]] = None
    ) -> None:
        """Load documents from a directory."""
        try:
            directory_path = Path(directory_path)
            if not directory_path.exists():
                raise FileNotFoundError(f"Directory not found: {directory_path}")
            
            reader = SimpleDirectoryReader(str(directory_path))
            documents = reader.load_data()
            
            # Add source information
            for doc in documents:
                if 'source' not in doc.metadata:
                    doc.metadata['source'] = str(directory_path)
            
            self.add_documents(documents, tags)
            
        except Exception as e:
            self.logger.error(
                "Failed to load from directory", 
                directory=str(directory_path),
                error=str(e)
            )
            raise
    
    def search(
        self, 
        query: str, 
        top_k: Optional[int] = None
    ) -> List[Dict[str, Any]]:
        """Search the knowledge base."""
        try:
            top_k = top_k or self.config.get('similarity_top_k', 4)
            response = self.query_engine.query(query)
            
            results = []
            for node in response.source_nodes or []:
                results.append({
                    "content": node.node.get_content(),
                    "score": getattr(node, 'score', 0.0),
                    "metadata": node.node.metadata,
                    "node_id": node.node.node_id
                })
            
            return results
            
        except Exception as e:
            self.logger.error("Search failed", query=query, error=str(e))
            return []
    
    def get_stats(self) -> KnowledgeBaseStats:
        """Get knowledge base statistics."""
        try:
            total_docs = len(self.documents_metadata)
            
            # Get document types
            doc_types = {}
            for metadata in self.documents_metadata.values():
                doc_type = metadata.document_type
                doc_types[doc_type] = doc_types.get(doc_type, 0) + 1
            
            # Estimate index size
            index_size = 0
            if self.index_dir.exists():
                for file_path in self.index_dir.glob("*"):
                    if file_path.is_file():
                        index_size += file_path.stat().st_size
            
            return KnowledgeBaseStats(
                total_documents=total_docs,
                total_nodes=len(self.index.docstore.docs) if self.index else 0,
                last_updated=max(
                    (meta.updated_at for meta in self.documents_metadata.values()),
                    default=datetime.now()
                ),
                index_size=index_size,
                document_types=doc_types
            )
            
        except Exception as e:
            self.logger.error("Failed to get stats", error=str(e))
            return KnowledgeBaseStats(
                total_documents=0,
                total_nodes=0,
                last_updated=datetime.now(),
                index_size=0,
                document_types={}
            )
    
    def query(self, query_str: str):
        """Query the knowledge base."""
        return self.query_engine.query(query_str)
